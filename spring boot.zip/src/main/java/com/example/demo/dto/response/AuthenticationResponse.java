package com.example.demo.dto.response;

import lombok.Data;


@Data
public class AuthenticationResponse {
    String token;
}
