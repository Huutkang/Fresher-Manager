package com.example.demo.dto.response;

import lombok.Data;


@Data
public class Search {
    Integer id;
    String name;
    String username;
}
