package com.example.demo.dto.request;

import lombok.Data;




@Data
public class FresherProjectReqDto {
    private int idFresher;
    private int idProject;
    private String role;
}
