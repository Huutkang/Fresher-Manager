package com.example.demo.dto.internal;

import com.example.demo.entity.Center;

import lombok.Data;



@Data
public class FresherDto {
    private int idUser;
    private String programmingLanguage;
    private int idCenter;

}
