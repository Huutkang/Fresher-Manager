package com.example.demo.dto.request;

import lombok.Data;

@Data
public class CenterReqDto {
    private String name;
    private String location;
    private int idManager;
}
