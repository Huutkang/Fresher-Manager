package com.example.demo.dto.request;
public class NotificationReqDto {
    private int idFresher;
    private int idProject;
    private String message;
}
