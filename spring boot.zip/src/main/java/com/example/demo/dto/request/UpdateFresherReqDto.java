package com.example.demo.dto.request;


import lombok.Data;



@Data
public class UpdateFresherReqDto {
    private String programmingLanguage;
    private int idCenter;

}
