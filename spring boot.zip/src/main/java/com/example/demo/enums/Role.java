package com.example.demo.enums;


public enum Role {
    USER, 
    ADMIN,
    FRESHER
}